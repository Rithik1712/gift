let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn') .oneclick = () =>
{
	shoppingCart.classList.toggle('active');
} 

    var swiper = new Swiper(".swiper product-slider", {
      loop:true,
      spaceBetween: 20,

      autoplay:{
      	delay:7500,
      	disableonInteraction: false,

      },
  

      breakpoints: {
        0: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 2,
          
        1024: {
          slidesPerView: 3,
        },
      },
    });
