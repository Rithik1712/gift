let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn') .onclick = () =>
{
	shoppingCart.classList.toggle('active');
} 

<script>

    var swiper = new Swiper(".product-slider", {
      loop:true,
      spaceBetween: 20,

      autoplay:{
      	delay:7500,
      	disableonInteraction: false,

      },
  

      breakpoints: {
        0: {
          slidesPerView: 1,
        },
        768: {
          slidesPerView: 2,
          
        1024: {
          slidesPerView: 3,
        },
      },
    });
    
</script>



<script>

Let searchForm = document.querySelector('.search-form'); 

document.querySelector('#search-btn').onclick = () =>
{
  searchForm.classList.toggle('active');
} 

</script>